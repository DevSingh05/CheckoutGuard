import asyncio
import hashlib
import json
from typing import Protocol
from urllib.parse import urlsplit

from .brief import BriefWriter, template
from .cache import TTLCache
from .demo import MERCHANTS, demo_signals, demo_sources
from .models import AnalyzeRequest, AnalyzeResponse, Source, SourceResult
from .payments import amount_at_stake, guidance
from .providers.common import provider_failure
from .scoring import decide, narrative, score


class Provider(Protocol):
    async def check(self, request: AnalyzeRequest, domain: str) -> SourceResult: ...


class Analyzer:
    def __init__(
        self,
        providers: dict[Source, Provider],
        timeout: float = 45,
        ttl: int = 900,
        brief: BriefWriter | None = None,
    ):
        self.providers = providers
        self.brief = brief or BriefWriter()
        self.timeout = timeout
        self.cache = TTLCache(ttl)
        self.semaphore = asyncio.Semaphore(6)

    def cache_key(self, source, request, domain):
        identity = [source, domain]
        if source == "instagram":
            identity.append(request.instagramLinks)
        if source == "reviews":
            identity.extend([request.url, request.reviews])
        if source == "store":
            signals = request.pageSignals
            identity.extend([request.url, signals.model_dump(mode="json") if signals else None])
        return hashlib.sha256(json.dumps(identity, ensure_ascii=False).encode()).hexdigest()

    async def run_source(self, source, request, domain):
        key = self.cache_key(source, request, domain)
        cached = self.cache.get(key)
        if cached and not request.refresh:
            return cached
        try:
            async with asyncio.timeout(self.timeout):
                async with self.semaphore:
                    raw = await self.providers[source].check(request, domain)
                    result = SourceResult.model_validate(raw)
                    if result.source != source:
                        raise ValueError("Wrong provider identity")
        except Exception as error:
            # Do not log provider responses, raw reviews, URLs, or credential-bearing exceptions.
            return provider_failure(source, error)
        self.cache.put(key, result)
        return result

    async def analyze(self, request: AnalyzeRequest):
        domain = urlsplit(request.url).hostname.lower().removeprefix("www.")
        if request.demo:
            domain = MERCHANTS[request.demo]
            sources = demo_sources(request.demo)
        else:
            sources = await asyncio.gather(
                *(self.run_source(s, request, domain) for s in self.providers)
            )
        for source in sources:
            if source.source == "reviews":
                source.limitations = (source.limitations + request.extractionLimitations)[:20]
        signals = demo_signals(request.demo) if request.demo else request.pageSignals
        risk, coverage = score(sources)
        payment = guidance(signals.paymentMethods if signals else None)
        summary, steps = narrative(risk, coverage, payment.recommended, payment.observed)
        result = AnalyzeResponse(
            domain=domain,
            productTitle="Everyday travel pack" if request.demo else request.productTitle,
            overallRisk=risk,
            coverage=coverage,
            limitedEvidence=coverage < 60,
            summary=summary,
            nextSteps=steps,
            sources=sources,
            decision=decide(risk, coverage, sources, payment, signals),
            payment=payment,
            amountAtStake=amount_at_stake(signals),
            demo=bool(request.demo),
        )
        # Demo stays offline and deterministic.
        result.brief = template(result) if request.demo else await self.brief.write(result)
        return result
