import asyncio
from unittest.mock import AsyncMock

import httpx
import pytest

from app import main
from app.models import AnalyzeRequest, SourceResult
from app.service import Analyzer


def providers():
    return {
        name: type(
            "Provider",
            (),
            {
                "check": AsyncMock(
                    return_value=SourceResult(
                        source=name, status="available", score=70 if name != "reviews" else 10
                    )
                )
            },
        )()
        for name in ("reddit", "instagram", "store", "reviews")
    }


def call(payload):
    async def run():
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=main.app), base_url="http://test"
        ) as client:
            return await client.post("/analyze", json=payload)

    return asyncio.run(run())


@pytest.fixture
def engine(monkeypatch):
    p = providers()
    engine = Analyzer(p, timeout=0.02)
    monkeypatch.setattr(main, "analyzer", engine)
    return engine


def test_success(engine):
    response = call({"url": "https://shop.example/products/bag"})
    assert response.status_code == 200
    assert response.json()["coverage"] == 100
    assert response.json()["overallRisk"] == 64


def test_malformed_response_partial_success(engine):
    engine.providers["reddit"].check.return_value = {"status": "invented"}
    result = call({"url": "https://shop.example/a"}).json()
    assert result["coverage"] == 60
    assert not result["limitedEvidence"]
    assert result["sources"][0]["status"] == "error"


def test_individual_timeout(engine):
    async def slow(*args):
        await asyncio.sleep(0.1)

    engine.providers["instagram"].check.side_effect = slow
    result = call({"url": "https://shop.example/a"}).json()
    assert result["coverage"] == 70
    assert result["sources"][1]["status"] == "error"


def test_all_fail(engine):
    for p in engine.providers.values():
        p.check.side_effect = RuntimeError("private provider error")
    result = call({"url": "https://shop.example/a"}).json()
    assert result["overallRisk"] is None
    assert result["coverage"] == 0
    assert "private provider" not in str(result)


def test_product_cache_isolation(engine):
    async def run():
        a = AnalyzeRequest(url="https://shop.example/a", reviews=["first sample"])
        b = AnalyzeRequest(url="https://shop.example/b", reviews=["different sample"])
        await engine.analyze(a)
        result = await engine.analyze(b)
        assert result.sources[0].cached
        assert not result.sources[3].cached
        result = await engine.analyze(b)
        assert result.sources[3].cached
        assert engine.providers["reviews"].check.await_count == 2
        assert engine.providers["reddit"].check.await_count == 1

    asyncio.run(run())


def test_changed_reviews_same_product_isolate(engine):
    async def run():
        await engine.analyze(AnalyzeRequest(url="https://shop.example/a", reviews=["one"]))
        result = await engine.analyze(AnalyzeRequest(url="https://shop.example/a", reviews=["two"]))
        assert not result.sources[3].cached

    asyncio.run(run())


def test_force_refresh(engine):
    call({"url": "https://shop.example/a"})
    response = call({"url": "https://shop.example/a", "refresh": True})
    assert not any(s["cached"] for s in response.json()["sources"])


@pytest.mark.parametrize("scenario", ["warning", "positive", "limited", "outage"])
def test_demo_without_providers(engine, scenario):
    result = call({"url": "https://ignored.example", "demo": scenario}).json()
    assert result["demo"] and result["domain"].endswith(".example")
    assert all(p.check.await_count == 0 for p in engine.providers.values())
    assert [s["source"] for s in result["sources"]] == ["reddit", "instagram", "store", "reviews"]
    verdict, limited, store = {
        "warning": ("pause", False, "available"),
        "positive": ("proceed", False, "available"),
        "limited": ("protect", True, "insufficient-data"),
        "outage": ("protect", False, "available"),  # reddit + store = 60% coverage
    }[scenario]
    assert result["decision"]["verdict"] == verdict
    assert result["limitedEvidence"] is limited
    assert result["sources"][2]["status"] == store
    assert result["brief"]["generated"] is False
    assert result["payment"]["recommended"] == "credit-card"
    assert 3 <= len(result["payment"]["disputeSteps"]) <= 5
    findings = [f for s in result["sources"] for f in s["findings"]]
    assert all(f["verification"] == "fictional" for f in findings)
    assert all(f["url"].startswith(f"https://{result['domain']}/") for f in findings)


def test_warning_demo_store_evidence(engine):
    result = call({"url": "https://ignored.example", "demo": "warning"}).json()
    store = result["sources"][2]
    assert store["score"] == 70 and result["overallRisk"] == 72
    assert store["findings"][0]["title"] == "Domain registered 23 days ago"
    assert store["findings"][0]["kind"] == "verified-fact"
    assert result["amountAtStake"]["discountPercent"] == 72
    assert [o["method"] for o in result["payment"]["options"]] == ["credit-card", "crypto", "zelle"]
    assert "Zelle and Cryptocurrency" in result["payment"]["warning"]


def test_private_url_rejected(engine):
    assert call({"url": "http://127.0.0.1/admin"}).status_code == 422


def test_payload_limit(engine):
    assert call({"url": "https://shop.example", "reviews": ["a" * 100001]}).status_code == 413


def test_page_signals_isolate_store_cache(engine):
    async def run():
        url = "https://shop.example/a"
        await engine.analyze(AnalyzeRequest(url=url))
        signals = {"paymentMethods": ["paypal"]}
        result = await engine.analyze(AnalyzeRequest(url=url, pageSignals=signals))
        assert result.sources[0].cached and not result.sources[2].cached
        assert engine.providers["store"].check.await_count == 2

    asyncio.run(run())


def test_old_client_without_page_signals(engine):
    result = call({"url": "https://shop.example/a", "productTitle": "Bag"}).json()
    assert result["amountAtStake"] is None
    assert result["payment"]["recommended"] == "credit-card"
    assert result["decision"]["verdict"] == "pause"  # risk 64
    assert len(result["decision"]["headline"]) <= 120


def test_page_signals_shape_payment(engine):
    signals = {
        "paymentMethods": ["zelle", "paypal", "zelle"],
        "price": 30,
        "compareAtPrice": 100,
        "currency": "EUR",
    }
    result = call({"url": "https://shop.example/a", "pageSignals": signals}).json()
    assert [o["method"] for o in result["payment"]["options"]] == ["paypal", "zelle"]
    assert result["amountAtStake"] == {
        "price": 30.0,
        "compareAtPrice": 100.0,
        "currency": "EUR",
        "discountPercent": 70,
    }
    bad = call({"url": "https://shop.example/a", "pageSignals": {"paymentMethods": ["cash"]}})
    assert bad.status_code == 422


def test_health_reports_presence_without_exposing_keys(monkeypatch):
    monkeypatch.setattr(main.settings, "backboard_api_key", "private-test-key")

    async def run():
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=main.app), base_url="http://test"
        ) as client:
            return await client.get("/health")

    response = asyncio.run(run())
    assert response.status_code == 200
    assert response.json()["providers"]["reddit"] is True
    assert response.json()["version"] == "0.2.0"
    assert "private-test-key" not in response.text
